//
//  SplashScreenController.swift
//  GiphyLiveLike
//
//  Created by Nikhil on 03/11/21.
//

import Foundation
import UIKit

class SplashScreenController: UIViewController {

    @IBOutlet weak var weBelieveLabel: UILabel!
    @IBOutlet weak var logo: UIImageView!
    var height = 150
    
    @IBOutlet weak var heightOfLogoImage: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
     
        weBelieveLabel.alpha = 0
    }
    
    override func viewDidAppear(_ animated: Bool) {
   
        dismissSplashController()
      

    }
  
    // MARK:- Play Animation

    @objc func dismissSplashController() {
        UIView.animate(withDuration: 3, animations: {
            self.heightOfLogoImage.constant = CGFloat(self.height)
           // self.weBelieveLabel.alpha = 1
            self.view.layoutIfNeeded()
            
        }) { (_) in
            UIView.animate(withDuration: 1, animations: { 
            self.weBelieveLabel.alpha = 1//1
            }) { (_) in
             
                appDelegate.dismissSplashController()
            }

        }
    }

}
