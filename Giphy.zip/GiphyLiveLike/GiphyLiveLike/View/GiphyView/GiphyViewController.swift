//
//  ViewController.swift
//  GiphyLiveLike
//
//  Created by Nikhil on 02/11/21.
//

import UIKit

class GiphyViewController: UIViewController {
    
    @IBOutlet weak var giphyTableView: UITableView!
    
    var giphyTrendingData: [GiphyTrendingData]?
    var giphySearchData: [GiphyTrendingData]?
    lazy var loadingOperations = [IndexPath : DataLoadOperation]()
    lazy var loadingQueue = OperationQueue()
    var searchActive :Bool = false
    let searchController = UISearchController(searchResultsController: nil)
    var refreshControl: UIRefreshControl?


   
    // MARK:- Viewcontroller Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
           
            
            setupSearchBar()
            createRefreshControl()
            setupTableViewBackgroundView()
      
        
    }
  
    
    override func viewDidAppear(_ animated: Bool) {

        getTrendingGifs()
    }
    
    // MARK:- Get Trending Gifs

    fileprivate func getTrendingGifs() {
        SessionHelper.shared.getRequestHelper(vc: self, api: APIs.trendingGiphy, completionHandler: { data in
            
            SessionHelper.shared.decode(data, completion: { (trendingData: TrendingData) in
                self.giphyTrendingData = trendingData.data
                
                DispatchQueue.main.async {
                    
                    self.giphyTableView.reloadData()
                    self.endRefreshing()

                    
                    
                }
            }, vc: self)
            
            
            
        })
    }
    // MARK:- Initial Setup
    
   

    func setupSearchBar() {

        
        searchController.searchBar.delegate = self
        searchController.dimsBackgroundDuringPresentation = false
        searchController.hidesNavigationBarDuringPresentation = false
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = true
        searchController.searchBar.placeholder = "Search Gifs"
        definesPresentationContext = true
       // giphyTableView.tableHeaderView = searchController.searchBar
        giphyTableView.tableFooterView = UIView()
        navigationController?.navigationBar.prefersLargeTitles = true

    }
    
    func createRefreshControl() {
        if self.refreshControl != .none {return}
        self.refreshControl = UIRefreshControl()
        self.refreshControl?.attributedTitle = NSAttributedString(string: " ↓ Refresh ↓ ")
          giphyTableView.addSubview(refreshControl!)
        refreshControl?.addTarget(self, action: #selector(refresh), for: .valueChanged)

    }
     func setupTableViewBackgroundView() {
        let backgroundViewLabel = UILabel(frame: .zero)
        backgroundViewLabel.center = self.view.center
        backgroundViewLabel.textColor = .darkGray
        backgroundViewLabel.numberOfLines = 0
        backgroundViewLabel.text = " Oops, No results to show "
        backgroundViewLabel.textAlignment = NSTextAlignment.center
        backgroundViewLabel.font.withSize(20)
        giphyTableView.backgroundView = backgroundViewLabel
    }
  


}
// MARK:- Refresh process

extension GiphyViewController{
    
    func deleteRefreshControl() {
        if self.refreshControl == .none {return}
        refreshControl?.removeFromSuperview()
        self.refreshControl = nil
    }

    @objc func refresh(_ sender: Any) {
        if searchActive{
            refreshControl?.endRefreshing()
        }else{
            self.searchController.searchBar.isUserInteractionEnabled = false
            self.loadingOperations.removeAll()
            getTrendingGifs()
        }
    }
    func endRefreshing(){
        if refreshControl?.isRefreshing ?? false{
            
            self.refreshControl?.endRefreshing(completion: {
                Timer.scheduledTimer(withTimeInterval: 1, repeats: false, block: {_ in
                    self.searchController.searchBar.isUserInteractionEnabled = true
                })
            })
        }
    }
}
// MARK:- Table Delegate and Datasource

extension GiphyViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchActive ? giphySearchData?.count ?? 0 :  giphyTrendingData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         var cell = tableView.dequeueReusableCell(withIdentifier: "GiphyTableCell") as? GiphyTableCell
        
        if cell == nil {
            cell = GiphyTableCell(style: .default, reuseIdentifier: "GiphyTableCell")
        }
        return cell!
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        let tCell = cell as! GiphyTableCell
        
        let updateCellClosure: (UIImage?) -> () = { [unowned self] (image) in
            tCell.updateAppearanceFor(image)
            self.loadingOperations.removeValue(forKey: indexPath)
        }
        
        if let dataLoader = loadingOperations[indexPath] {
            // Has the data already been loaded?
            if let image = dataLoader.image {
                tCell.updateAppearanceFor(image)
                loadingOperations.removeValue(forKey: indexPath)
            } else {
                dataLoader.loadingCompleteHandler = updateCellClosure
            }
        } else {
            guard let modelData = searchActive ? giphySearchData : giphyTrendingData else {return}
            if let dataLoader = CreateDataLoader.loadImage(at: indexPath.row, modelData: modelData) {
                dataLoader.loadingCompleteHandler = updateCellClosure
                loadingQueue.addOperation(dataLoader)
                loadingOperations[indexPath] = dataLoader
            }
        }
        
    }
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {

        if let dataLoader = loadingOperations[indexPath] {
            dataLoader.cancel()
            loadingOperations.removeValue(forKey: indexPath)
        }
    }
    
    
    
    
}
// MARK:- Prefetch Operation

extension GiphyViewController: UITableViewDataSourcePrefetching {
    func tableView(_ tableView: UITableView, prefetchRowsAt indexPaths: [IndexPath]) {

        for indexPath in indexPaths {
            if let _ = loadingOperations[indexPath] {
                
                return }
            guard let modelData = searchActive ? giphySearchData : giphyTrendingData else {return}
            if let dataLoader = CreateDataLoader.loadImage(at: indexPath.row, modelData: modelData) {
                loadingQueue.addOperation(dataLoader)
                loadingOperations[indexPath] = dataLoader
            }
        }
    }
    
    func tableView(_ tableView: UITableView, cancelPrefetchingForRowsAt indexPaths: [IndexPath]) {

        for indexPath in indexPaths {
            if let dataLoader = loadingOperations[indexPath] {
                dataLoader.cancel()
                loadingOperations.removeValue(forKey: indexPath)
            }
        }
    }
}

// MARK:- Search Operation

extension GiphyViewController: UISearchBarDelegate{
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        deleteRefreshControl()

    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText : String) {
       
        guard let textToSearch = searchBar.text, !textToSearch.isEmpty else {
            Singleton.shared.searchText = ""
            self.loadingOperations.removeAll()
            searchActive = false
            getTrendingGifs()
            return
        }
        searchActive = true
        deleteRefreshControl()
        Singleton.shared.searchText = textToSearch
        
        SessionHelper.shared.getRequestHelper(vc: self, api: APIs.searchGiphy, completionHandler: { data in

            SessionHelper.shared.decode(data, completion: { (trendingData: TrendingData) in
                self.giphySearchData = trendingData.data
                self.loadingOperations.removeAll()

                DispatchQueue.main.async {
                    self.giphyTableView.reloadData()
                    self.endRefreshing()
                }
            }, vc: self)

        })
        
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {

               searchBar.resignFirstResponder()
        
    }
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
        if let searchTextField = searchBar.value(forKey: "searchField") as? UITextField , let clearButton = searchTextField.value(forKey: "_clearButton")as? UIButton {
            clearButton.addTarget(self, action:  #selector(searchBarDidClickCrossButton(_ :)), for: .touchUpInside)
        }
  
        return true
    }
    @objc  func searchBarDidClickCrossButton(_ button:UIButton ) {

        searchBar(searchController.searchBar, textDidChange: "")
            
        }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        self.searchBar(searchBar, textDidChange: "")
        createRefreshControl()

    }

}



