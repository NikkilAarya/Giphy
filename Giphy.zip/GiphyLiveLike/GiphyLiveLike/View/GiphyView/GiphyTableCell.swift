//
//  GiphyTableCell.swift
//  GiphyLiveLike
//
//  Created by Nikhil on 02/11/21.
//

import UIKit

class GiphyTableCell: UITableViewCell {

    @IBOutlet weak var giphyImageView: UIImageView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
   

    // MARK:- Update image

    func updateAppearanceFor(_ image: UIImage?) {
        DispatchQueue.main.async { [unowned self] in
            self.displayImage(image)
        }
    }
    
    private func displayImage(_ image: UIImage?) {
        if let _image = image {
            giphyImageView.image = _image
            activityIndicator.stopAnimating()
        } else {
            activityIndicator.startAnimating()
            giphyImageView.image = .none
        }
    }

    override func prepareForReuse() {
        giphyImageView.image = nil
        activityIndicator.startAnimating()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
