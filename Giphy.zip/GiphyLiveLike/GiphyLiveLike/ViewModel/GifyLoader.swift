//
//  GifyLoader.swift
//  GiphyLiveLike
//
//  Created by Nikhil on 02/11/21.
//

import Foundation
import UIKit

class ImageCache: NSObject {

    private var cache = NSCache<AnyObject, UIImage>()
    public static let shared = ImageCache()
    private override init() {}
   
    func getCache() -> NSCache<AnyObject, UIImage> {
       return cache
    }
}

class CreateDataLoader{
   
    class func loadImage(at index: Int, modelData: [GiphyTrendingData]) -> DataLoadOperation? {
    
        if (0..<modelData.count).contains(index) {
            return DataLoadOperation(modelData[index])
        }
        return .none
    }
}

class DataLoadOperation: Operation {
    var image: UIImage?
    var loadingCompleteHandler: ((UIImage?) -> ())?
    var modelData: GiphyTrendingData?
    
    init(_ data: GiphyTrendingData) {
        modelData = data
    }
    public final func getCacheImage(url: NSURL) -> UIImage? {
        return ImageCache.shared.getCache().object(forKey: url)
    }
    override func main() {
        if isCancelled { return }
        guard let strUrl = modelData?.images.preview_gif.url, let url = URL(string: strUrl ) else { return }
        
        downloadImageFrom(url) { (image) in
            DispatchQueue.main.async() { [weak self] in
                guard let `self` = self else { return }
                if self.isCancelled { return }
                self.image = image
                ImageCache.shared.getCache().setObject(image ?? UIImage(), forKey: url as NSURL)

                self.loadingCompleteHandler?(self.image)
            }
        }
        
    }
    
    func downloadImageFrom(_ url: URL, completeHandler: @escaping (UIImage?) -> ()) {
        
        if let cachedImage = getCacheImage(url: url as NSURL) {
            DispatchQueue.main.async {
                completeHandler(cachedImage)
            }
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
               // let mimeType = response?.mimeType, mimeType.hasPrefix("Gif"),
                let data = data, error == nil,
                let _image = UIImage.gifImageWithData(data)// UIImage(data: data)
            
                else { return }
            completeHandler(_image)
            }.resume()
    }
   

    
    
}
