//
//  Constants.swift
//  GiphyLiveLike
//
//  Created by Nikhil on 02/11/21.
//

import Foundation
import UIKit

let appDelegate = (UIApplication.shared.delegate as! AppDelegate)
let story_Board = UIStoryboard.init(name: "Main", bundle: nil)

func getDeviceType() -> UIUserInterfaceIdiom? {
  let deviceIdiom = UIScreen.main.traitCollection.userInterfaceIdiom

    // 2. check the idiom
    switch (deviceIdiom) {

    case .pad:
        return .pad
    case .phone:
        return .phone
    case .tv:
        return .tv
    default:
        return nil

    }
 
  }
