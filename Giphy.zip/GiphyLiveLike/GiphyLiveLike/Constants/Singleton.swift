//
//  Singleton.swift
//  GiphyLiveLike
//
//  Created by Nikhil on 02/11/21.
//

import Foundation
import UIKit

class Singleton {
   static let shared = Singleton()
   
    var searchText:String?{
        didSet{
            APIs.searchGiphy = "https://api.giphy.com/v1/gifs/search?api_key=\(APIs.Api_Key)&q=\(searchText ?? "")&limit=200&offset=0&rating=g&lang=en"
        }
        
    }
   
   
    // MARK:- Color from hexcolor
    func hexStringToUIColor (hex:String) -> UIColor
    {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }

    
    
    func showAlert(vc:UIViewController, title:String? = nil, message:String) {
       
        let alertVc = UIAlertController(title: title, message: message, preferredStyle: .alert)
        if title != nil {
            alertVc.setValue(NSAttributedString(string: title!, attributes: [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 15),NSAttributedString.Key.foregroundColor : UIColor.red]), forKey: "attributedTitle")
        }

        let alertAction = UIAlertAction(title: "Ok", style: .destructive, handler: nil)
        alertVc.addAction(alertAction)
//        alertAction.setValue(NSAttributedString(string: "OK", attributes: [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 15),NSAttributedString.Key.foregroundColor : UIColor.black]), forKey: "attributedTitle")
        vc.present(alertVc, animated: true, completion: nil)

    }
    
  

   
}
