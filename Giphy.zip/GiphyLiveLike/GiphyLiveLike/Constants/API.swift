//
//  API.swift
//  GiphyLiveLike
//
//  Created by Nikhil on 02/11/21.
//

import Foundation

import Foundation

class APIs {
    
    static let Api_Key = "nbE0bzNcKj8c4z5U3BCe8BHSd8fL8V5D"
    static let trendingGiphy = "https://api.giphy.com/v1/gifs/trending?api_key=\(Api_Key)&limit=200&rating=g"
    
    static var searchGiphy = "https://api.giphy.com/v1/gifs/search?api_key=\(Api_Key)&q=\(Singleton.shared.searchText)&limit=200&offset=0&rating=g&lang=en"
}
