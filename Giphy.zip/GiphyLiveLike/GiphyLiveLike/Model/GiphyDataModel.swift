//
//  GiphyDataModel.swift
//  GiphyLiveLike
//
//  Created by Nikhil on 02/11/21.
//

import Foundation

// MARK:- DataModel for Gifs


struct TrendingData:Codable {
    var data:[GiphyTrendingData]
}
struct GiphyTrendingData:Codable {
    var images:Original
}

struct Original:Codable  {
    var preview_gif : RequiredUrl
}

struct RequiredUrl:Codable  {
    var url: String
}
