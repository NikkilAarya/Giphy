//
//  Extension.swift
//  GiphyLiveLike
//
//  Created by Nikhil on 03/11/21.
//

import Foundation
import UIKit

// MARK:- Handler for refresh

extension UIRefreshControl {
    func endRefreshing(completion:@escaping ()->()) {
        UIView.animate(withDuration: 0, animations: endRefreshing)
            { _ in completion() }
    }
}
