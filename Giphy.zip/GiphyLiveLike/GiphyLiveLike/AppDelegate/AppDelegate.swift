//
//  AppDelegate.swift
//  GiphyLiveLike
//
//  Created by Nikhil on 02/11/21.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
   var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        return true
    }

    func extendSplashScreenPresentation(){
       let splashController = story_Board.instantiateViewController(withIdentifier: "SplashScreenController") as! SplashScreenController
       self.window?.rootViewController = splashController
       self.window?.makeKeyAndVisible()
   }
    @objc  func dismissSplashController() {
            let gifVc = story_Board.instantiateViewController(withIdentifier: "GiphyViewController") as! GiphyViewController
                gifVc.title = "Gify"
                let nav = UINavigationController(rootViewController: gifVc)
                window?.rootViewController = nav

    }
  


}

