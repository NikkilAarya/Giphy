//
//  SessionManager.swift
//  GiphyLiveLike
//
//  Created by Nikhil on 02/11/21.
//



import Foundation

import Foundation
import UIKit

class SessionManager:NSObject {

static let shared = SessionManager()
    
    var session:URLSession?
   weak var vcObject:UIViewController!
    var completionHandler:((Data)->())?
    var savedCompletionHandler: (() -> Void)?
    var downloadTask:URLSessionDownloadTask?
    
    override init() {
        super.init()

    
        let bundleID = Bundle.main.bundleIdentifier
        let configuration = URLSessionConfiguration.background(withIdentifier: "\(bundleID).background")
        configuration.sessionSendsLaunchEvents = true
        configuration.timeoutIntervalForRequest = 4*60
        configuration.isDiscretionary = false
        configuration.allowsCellularAccess = true
        configuration.waitsForConnectivity = false
        session = URLSession(configuration: configuration, delegate: self, delegateQueue: OperationQueue.main)

        
    }
    
    // MARK: - GetRequest, Download Task
    func getRequest(urlString:String, _ vc: UIViewController? = nil, completionHandler: @escaping(Data)->()  )  {
        guard let url = URL(string: urlString) else {return}
    var request = URLRequest(url: url,timeoutInterval: Double.infinity)
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.httpMethod = "GET"
    self.vcObject = vc
    self.completionHandler = completionHandler

        if !Reach.isConnectedToNetwork(){
        
            SessionManager.shared.downloadTask?.cancel()
            ERProgressHud.sharedInstance.hide()
            Singleton.shared.showAlert(vc: self.vcObject , message:  "Network connection lost" )

         
             
            return
        }
        downloadTask =  session?.downloadTask(with: request)
        downloadTask?.resume()


    }
    
    
    
    
}

extension SessionManager: URLSessionDownloadDelegate {

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        var file:FileHandle?
        
        do {
        file = try FileHandle(forReadingFrom: location)
        }catch{
            if ERProgressHud.sharedInstance.presented  {
                 //LoaderViewController.present.remove()
             ERProgressHud.sharedInstance.hide()
                Singleton.shared.showAlert(vc: self.vcObject , message: error.localizedDescription )

             }
            print("\(error.localizedDescription)")
            return
        }

   
        DispatchQueue.main.async {
           // print(location)
            do {
                guard  let data = file?.readDataToEndOfFile() else {
                if ERProgressHud.sharedInstance.presented  {
                  ERProgressHud.sharedInstance.hide()
               
                Singleton.shared.showAlert(vc: self.vcObject , message: "Exception:Could not read the data" )


                 }
                return}

                self.completionHandler?(data as Data)
            } catch {
                if ERProgressHud.sharedInstance.presented  {
                  ERProgressHud.sharedInstance.hide()
                    Singleton.shared.showAlert(vc: self.vcObject , message: error.localizedDescription ?? "Network error, please try again" )


                 }
                print("\(error.localizedDescription)")
            }
        }
   
    }

}

