//
//  SessionHelper.swift
//  GiphyLiveLike
//
//  Created by Nikhil on 02/11/21.
//

import Foundation

import UIKit

class SessionHelper {
    
    static let shared = SessionHelper()
    
    func getRequestHelper( vc:UIViewController, api:String, completionHandler:@escaping(Data)->()) {
    
        SessionManager.shared.getRequest(urlString: api, vc, completionHandler: { data in
    
                completionHandler(data)
           

            
        })
     }
    
    func decode<T: Decodable>(_ data: Data, completion: ((T) -> Void), vc: UIViewController )  {
        do {
            let model = try JSONDecoder().decode(T.self, from: data)
            completion(model)
            
        } catch {
         //   print(error)
            if ERProgressHud.sharedInstance.presented  {
              ERProgressHud.sharedInstance.hide()
                Singleton.shared.showAlert(vc: vc, message: error.localizedDescription)
                return

              }
            
        }
        return
    }
    
    
}
